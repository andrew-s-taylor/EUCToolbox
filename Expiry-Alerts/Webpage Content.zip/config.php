<?php
define('webhook',"WEBHOOKHERE");
define('appID','APPID');
define('appSecret','APPSECRET');
define('htmltemplate','HTMLTEMPLATE');
define('sendgridtoken','SENDGRIDTOKEN');


?>