<?php
define('appID','APPID');
define('appSecret','APPSECRET');
define('webhook','WEBHOOK');
define('sendgridtoken','SENDGRIDTOKEN');

?>