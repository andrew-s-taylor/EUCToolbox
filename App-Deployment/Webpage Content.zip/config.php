<?php
//Webhook URL for community deployment scrit
define('webhookcommunity',"COMMUNITYWEBHOOKHERE");
define('webhookmanifest',"MANIFESTWEBHOOKHERE");

//Webhook secret
define('appID','APPID');
define('appSecret','APPSECRET');
define('sendgridtoken', 'SENDGRIDTOKEN');


?>